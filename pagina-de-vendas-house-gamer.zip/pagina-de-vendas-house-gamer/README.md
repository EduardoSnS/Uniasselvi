# Pagina de Vendas (House Gamer)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Menino-Sans/pen/ExrgYOO](https://codepen.io/Menino-Sans/pen/ExrgYOO).

